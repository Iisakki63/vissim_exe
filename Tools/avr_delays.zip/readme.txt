Vissim average delays tool:
python avr_delays.py test.rsrx test.delx
